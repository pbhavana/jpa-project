package com.cg.dao.impl;

import javax.persistence.PersistenceContext;

import org.springframework.orm.jpa.EntityManagerFactoryInfo;

public class JPACarDAO {
	
	@PersistenceContext
private EntityManager manager;
}
